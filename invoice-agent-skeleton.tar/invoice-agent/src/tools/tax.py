"""
validate_tax tool.

In production this calls CRA (Canada Business Number registry) or VIES (EU VAT).
In the skeleton, we do format validation only, plus a small allowlist of
"known-valid" tax IDs in src/data/tax_registry.json.
"""

from __future__ import annotations

import re

from src.agent.schemas import (
    ErrorEnvelope,
    ValidateTaxInput,
    ValidateTaxOutput,
)

# Format hints — extend as you cover more jurisdictions
TAX_ID_PATTERNS: dict[str, str] = {
    "CA": r"^\d{9}([A-Z]{2}\d{4})?$",  # Business Number, optional program account
    "US": r"^\d{2}-\d{7}$",  # EIN
    "GB": r"^GB\d{9}$",
    "DE": r"^DE\d{9}$",
}


def validate_tax(inp: ValidateTaxInput) -> ValidateTaxOutput:
    """
    TODO (you fill this in):

    1. Check inp.country is in TAX_ID_PATTERNS
       - If not, return ok=True, valid=False (unsupported country, but tool
         itself didn't fail)

    2. Match inp.tax_id against the pattern for that country
       - If format fails, return ok=True, valid=False

    3. Load src/data/tax_registry.json — a dict of {tax_id: registered_name}
       - If inp.tax_id present → ok=True, valid=True, registered_name=...
       - Else → ok=True, valid=False

    Design note: this tool distinguishes "ok" (the tool worked) from "valid"
    (the tax ID is good). This matters — a 500 from the registry should be
    ok=False so the agent can retry; a valid format but unknown ID is
    ok=True, valid=False because that's a real answer.
    """
    raise NotImplementedError("Implement validate_tax — see TODO in src/tools/tax.py")
