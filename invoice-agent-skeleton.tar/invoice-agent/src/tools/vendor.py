"""
lookup_vendor tool.

Reads src/data/vendor_master.json. Returns Vendor with bank_account_on_file
so the agent can compare against the invoice's bank account and detect
bank-detail-change fraud.
"""

from __future__ import annotations

from src.agent.schemas import (
    ErrorEnvelope,
    LookupVendorInput,
    LookupVendorOutput,
)


def lookup_vendor(inp: LookupVendorInput) -> LookupVendorOutput:
    """
    TODO (you fill this in):

    1. Validate at least one of inp.tax_id or inp.name was provided
       Otherwise return ok=False with code="MISSING_LOOKUP_KEY"

    2. Load src/data/vendor_master.json (list of Vendor records)

    3. Match strategy:
       - If tax_id provided, exact match wins
       - Else case-insensitive name match
       - For partial / fuzzy matches, consider the lowercase substring match
         as a reasonable starting point

    4. If no match: ok=False, code="VENDOR_NOT_FOUND"
    5. If match: ok=True, data=Vendor(...)

    Edge case worth handling: multiple matches. For this skeleton, return the
    first match but log a warning. In production this would be ok=False with
    code="AMBIGUOUS_MATCH".
    """
    raise NotImplementedError("Implement lookup_vendor — see TODO in src/tools/vendor.py")
