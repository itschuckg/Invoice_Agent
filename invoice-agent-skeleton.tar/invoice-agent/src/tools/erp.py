"""
post_to_erp.

The agent does NOT call this. The orchestrator does, after the policy gates
return ERP_AUTO_POST. Kept here so the contract is visible.

In production: NetSuite SuiteREST POST, with idempotency_key as External ID
to prevent duplicate postings on retry.
"""

from __future__ import annotations

import hashlib

from src.agent.schemas import (
    ErrorEnvelope,
    PostToErpInput,
    PostToErpOutput,
)


def post_to_erp(inp: PostToErpInput) -> PostToErpOutput:
    """
    TODO (you fill this in):

    Skeleton behavior:
    1. Generate a deterministic erp_document_id from the idempotency_key
       (e.g., "NS-" + sha256(idempotency_key)[:12])
    2. Log the posting (for now just rich.print)
    3. Return ok=True with the erp_document_id

    Production behavior:
    - Check NetSuite for existing document with matching External ID
    - If exists, return its document ID (idempotent replay)
    - If not, POST and return new document ID
    - Handle 429 with retry envelope (retryable=True)
    - Handle 401 with retryable=False (auth needs human intervention)
    """
    raise NotImplementedError("Implement post_to_erp — see TODO in src/tools/erp.py")
