"""
lookup_po and lookup_goods_receipt.

Both read from src/data/pos.json. The data file structure:
{
  "purchase_orders": [PurchaseOrder, ...],
  "goods_receipts": [GoodsReceipt, ...]
}
"""

from __future__ import annotations

from src.agent.schemas import (
    ErrorEnvelope,
    LookupGoodsReceiptInput,
    LookupGoodsReceiptOutput,
    LookupPOInput,
    LookupPOOutput,
)


def lookup_po(inp: LookupPOInput) -> LookupPOOutput:
    """
    TODO (you fill this in):

    1. Load src/data/pos.json
    2. Find a PO where po_number == inp.po_number
    3. Not found → ok=False, code="PO_NOT_FOUND"
    4. Found → ok=True, data=PurchaseOrder(...)

    Note: status="cancelled" POs should still be returned (so the agent can
    see and react). Don't filter them out — that's a business decision the
    agent makes, not the tool.
    """
    raise NotImplementedError("Implement lookup_po — see TODO in src/tools/po.py")


def lookup_goods_receipt(inp: LookupGoodsReceiptInput) -> LookupGoodsReceiptOutput:
    """
    TODO (you fill this in):

    1. Load src/data/pos.json
    2. Find a goods_receipt where po_number == inp.po_number
    3. Not found → ok=False, code="GR_NOT_FOUND" — this is informative,
       not necessarily an error; the agent decides what to do (e.g., goods
       not yet received means hold for exception)
    4. Found → ok=True, data=GoodsReceipt(...)
    """
    raise NotImplementedError(
        "Implement lookup_goods_receipt — see TODO in src/tools/po.py"
    )
