"""
screen_sanctions tool.

Mock implementation — checks supplier name against a small static list in
src/data/sanctions_list.json. Real implementation would call OFAC SDN,
EU consolidated list, or a commercial provider.
"""

from __future__ import annotations

from src.agent.schemas import (
    ErrorEnvelope,
    ScreenSanctionsInput,
    ScreenSanctionsOutput,
)


def screen_sanctions(inp: ScreenSanctionsInput) -> ScreenSanctionsOutput:
    """
    TODO (you fill this in):

    1. Load src/data/sanctions_list.json — list of {"name": str, "country": str}
    2. Case-insensitive substring match on name
       - "ACME Corp" should match a list entry "ACME"
       - Be conservative: false positives go to a human, false negatives slip through
    3. If country specified on input, allow matches with same country OR no country specified in list entry
    4. Hit → ok=True, is_hit=True, matched_against=entry["name"]
    5. No hit → ok=True, is_hit=False

    Note: real sanctions screening uses phonetic matching (Soundex/Metaphone),
    transliteration handling, and graph traversal for related entities.
    Substring match is the skeleton placeholder.
    """
    raise NotImplementedError(
        "Implement screen_sanctions — see TODO in src/tools/sanctions.py"
    )
