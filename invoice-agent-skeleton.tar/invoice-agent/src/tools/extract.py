"""
extract_invoice tool.

In production this calls Azure Document Intelligence or AWS Textract on a PDF.
In this skeleton it reads pre-parsed JSON from src/data/invoices/{invoice_id}.json
so we can focus on the agent loop rather than OCR.
"""

from __future__ import annotations

from src.agent.schemas import (
    ErrorEnvelope,
    ExtractInvoiceInput,
    ExtractInvoiceOutput,
)


def extract_invoice(inp: ExtractInvoiceInput) -> ExtractInvoiceOutput:
    """
    TODO (you fill this in):

    1. Build the path to src/data/invoices/{inp.invoice_id}.json
    2. If file does not exist, return ExtractInvoiceOutput(
           ok=False,
           error=ErrorEnvelope(
               code="INVOICE_NOT_FOUND",
               message=f"No invoice file for id {inp.invoice_id}",
               retryable=False,
           ),
       )
    3. Read the JSON
    4. Parse into ExtractedInvoice via model_validate
    5. Return ExtractInvoiceOutput(ok=True, data=parsed)

    Hint: use pathlib.Path(__file__).parent.parent / "data" / "invoices"
    """
    raise NotImplementedError("Implement extract_invoice — see TODO in src/tools/extract.py")
